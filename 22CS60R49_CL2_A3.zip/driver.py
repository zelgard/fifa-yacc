import awards
import stadium
import teams

def menu():
    pass
    
while True:
    print("##############MENU##############")
    print(f'Select the options for the \n1.View Teams \n2.View Stadium and Capacity\n3.View Awards\n4.Exit')
    option=int(input())
    if option==3:
        awards.run()
    elif option==1:
        teams.run()
    elif option==2:
        stadium.run()
    elif option==4:break
    else:
        print("Invalid Input")
        continue

