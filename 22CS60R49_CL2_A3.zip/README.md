Please first execute the driver program by executing driver.py
Select the given option as desired

NOTE: For the logging kindly exit the menu.

Kindly check log.txt for the same.