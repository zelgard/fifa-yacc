 
import ply.lex as lex
import ply.yacc as yacc
 
f2=open('log.txt','w',encoding='utf-8')
 
###DEFINING TOKENS###
 
tokens = ('BEGINTABLE', 'IMG',
'OPENTABLE', 'CLOSETABLE', 'OPENROW', 'CLOSEROW',
'OPENHEADER', 'CLOSEHEADER', 'OPENHREF', 'CLOSEHREF',
'CONTENT', 'OPENDATA', 'CLOSEDATA' ,'OPENSPAN',
'CLOSESPAN', 'OPENDIV', 'CLOSEDIV', 'OPENSTYLE', 'CLOSESTYLE','GARBAGE')
t_ignore = '\t'
 
 
###############Tokenizer Rules################
 
def t_BEGINTABLE(t):
 
    '''<table\sclass="wikitable"\sstyle="text-align:center">'''
 
    return t
 
 
def t_OPENTABLE(t):
    '''<tbody[^>]*>'''
    return t
 
def t_CLOSETABLE(t):
    '''</tbody[^>]*>'''
    return t
 
def t_OPENROW(t):
    '''<tr[^>]*>'''
    return t
 
def t_CLOSEROW(t):
    '''</tr[^>]*>'''
    return t
 
def t_OPENHEADER(t):
    '''<th[^>]*>'''
    return t
 
def t_CLOSEHEADER(t):
    '''</th[^>]*>'''
    return t
 
def t_OPENHREF(t):
    '''<a[^>]*>'''
    return t
 
def t_CLOSEHREF(t):
    '''</a[^>]*>'''
    return t
 
def t_OPENDATA(t):
    '''<td[^>]*>'''
    return t
 
def t_CLOSEDATA(t):
    '''</td[^>]*>'''
    return t
 
def t_CONTENT(t):
    '''[A-Za-z0-9, éíáć]+'''
    return t
 
def t_OPENDIV(t):
    '''<div[^>]*>'''
 
def t_CLOSEDIV(t):
    '''</div[^>]*>'''
 
def t_OPENSTYLE(t):
    '''<style[^>]*>'''
 
def t_CLOSESTYLE(t):
    '''</style[^>]*>'''
    
 
def t_OPENSPAN(t):
    '''<span[^>]*>'''
    return t
 
def t_CLOSESPAN(t):
    '''</span[^>]*>'''
    return t

def t_IMG(t):
    '''<img[^>]*>'''
    return t
 
def t_GARBAGE(t):
    r'<[^>]*>'
 
def t_error(t):
    t.lexer.skip(1)
 
 
####################Parsing Rules###############
 
def p_start(p):
    '''start : table'''
 
    p[0] = p[1]
 
def p_name(p):
    '''name : CONTENT
            | CONTENT name'''
    if len(p) == 3:
        #First production is getting evaluated
        p[0] = p[1] + ' ' + p[2]
    else:
        #2nd Production is getting evaluated
        p[0] = p[1]
 
def p_skiptag(p):
    '''skiptag : CONTENT skiptag
               | OPENHREF skiptag
               | CLOSEHREF skiptag
               | OPENSPAN skiptag
               | CLOSESPAN skiptag
               | IMG skiptag
               |'''
 
def p_handleData(p):
    '''handleData : OPENDATA OPENSPAN OPENHREF IMG CLOSEHREF CLOSESPAN CONTENT OPENHREF CONTENT CLOSEHREF CLOSEDATA handleData
                  | OPENDATA CONTENT CONTENT CLOSEDATA handleData
                  | OPENDATA OPENSPAN OPENHREF IMG CLOSEHREF CLOSESPAN CONTENT OPENHREF CONTENT CONTENT CONTENT CLOSEHREF CLOSEDATA handleData
                  | OPENDATA OPENSPAN OPENHREF IMG CLOSEHREF CLOSESPAN CONTENT OPENHREF CONTENT CONTENT CLOSEHREF CLOSEDATA handleData
                  | OPENDATA skiptag  CONTENT skiptag CLOSESPAN CLOSEDATA CLOSEROW handleData
                  |'''
    #Printing/Logging the output
    if len(p)==7:
        print(p[3])
        f2.write(p[3]+'\n')
    if len(p)==8:
        print(p[3])
        f2.write(p[3]+'\n')
    if(len(p) == 13 ):
        print(p[9])
        f2.write(p[9]+'\n')
    if(len(p) == 9 ):
        print(p[3])
        f2.write(p[3]+'\n')
    if len(p)==14 :
        print(p[9]+" "+p[10])
        f2.write(p[9]+" "+p[10]+'\n')
    if len(p)==15:
        print(p[9]+" "+p[10]+p[11])
        f2.write(p[9]+" "+p[10]+p[11]+'\n')
        
        
                  
 
def p_handlerow(p):
    '''handlerow : OPENROW OPENHEADER OPENHREF CONTENT CLOSEHREF CLOSEHEADER OPENHEADER CONTENT CLOSEHEADER OPENHEADER CONTENT CLOSEHEADER CLOSEROW handlerow
                 | OPENROW OPENHEADER OPENHREF CONTENT CLOSEHREF CLOSEHEADER CLOSEROW handlerow
                 | OPENROW handleData CLOSEROW handlerow
                 | '''
    

    

def p_table(p):
    '''table : BEGINTABLE OPENTABLE handlerow'''
 
 
def p_empty(p):
    '''empty :'''
    pass
 
def p_content(p):
    '''content : CONTENT
               | empty'''
    p[0] = p[1]
 
def p_error(p):
    pass
 
#########DRIVER FUNCTION#######
 
def run():
    file_obj= open('FIFA_Data.html','r',encoding="utf-8")
    data=file_obj.read()
    lexer = lex.lex()
    # lexer.input(data)
    # f = open("lex_cc.txt","w")
    # for tok in lexer:
    #     f.write(str(tok)+" \n ")
    parser = yacc.yacc()
    parser.parse(data)
    file_obj.close()
    
    # print(award)
    # print(player)
###############################################################################
#run()